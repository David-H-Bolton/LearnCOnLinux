#ifndef _timeh
#include <linux/time.h>
#define __timespec_defined 1
#define __itimerspec_defined 1
#include <time.h>
#define _timeh 1
#endif

#ifndef _hr_timer
#include "hr_time.h"

#define __timeval_defined 1
#include <stdlib.h>
#define _hr_timer 1
#endif


void startTimer(stopWatch *timer) {
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &timer->start);
}

void stopTimer(stopWatch *timer) {
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &timer->stop);
}

double diff(stopWatch *timer)
{
	struct timespec temp;
	if ((timer->stop.tv_nsec-timer->start.tv_nsec)<0) {
		temp.tv_sec = timer->stop.tv_sec-timer->start.tv_sec-1;
		temp.tv_nsec = 1000000000+timer->stop.tv_nsec-timer->start.tv_nsec;
	} else {
		temp.tv_sec = timer->stop.tv_sec-timer->start.tv_sec;
		temp.tv_nsec = timer->stop.tv_nsec-timer->start.tv_nsec;
	};
	return temp.tv_nsec/1000000000.0;
}

