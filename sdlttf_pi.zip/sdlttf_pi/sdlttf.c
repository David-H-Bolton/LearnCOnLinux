// sdltest.c
#include "hr_time.h"
#include <time.h>
#include "SDL2/SDL.h"   /* All SDL App's need this */
#include "SDL2/SDL_image.h" 
#include "SDL2/SDL_ttf.h"
#include <stdio.h>
#include <stdlib.h>


#define QUITKEY SDLK_ESCAPE
#define WIDTH 1024
#define HEIGHT 768

SDL_Window* screen = NULL;
SDL_Renderer* renderer;
SDL_Event event;
SDL_Rect source, destination, dst;
SDL_Texture* textFont;
SDL_Texture* ttfTexture;
TTF_Font* font;
SDL_Surface* surface;

int errorCount = 0;
int keypressed;
int rectCount = 0;
char* phrase = "Sphinx of black quartz, judge my vow";
stopWatch s;

/* returns a number between 1 and max */
int Random(int max) {
	return (rand() % max) + 1;
}

void LogError(char* msg) {
	FILE * err = fopen("errorlog.txt", "a");
	printf("%s\n", msg);
	fclose(err);
	errorCount++;
}

/* Sets Window caption according to state - eg in debug mode or showing fps */
void SetCaption(char* msg) {
	SDL_SetWindowTitle(screen, msg);
}

/* Load TTF_Font into VRAM */
TTF_Font* LoadFont(char* filename) {
	// load font.ttf at size 16 into font
	TTF_Font* _font;
	_font = TTF_OpenFont(filename, 32);
	if (!_font) {// handle error
		printf("TTF_OpenFont: %s\n", TTF_GetError());
		return 0;
	}
	return _font;
}

//. Puts errors in errorlog.txt file
void LogError2(const char* msg1, const char* msg2) {
	FILE* ferr;
	int error;
	ferr = fopen("errorlog.txt", "a");
	fprintf(ferr, "%s %s\n", msg1, msg2);
	fclose(ferr);
	errorCount++;
}

// Load Images
SDL_Texture* loadTexture(const char* afile, SDL_Renderer* ren) {
	SDL_Texture* texture = IMG_LoadTexture(ren, afile);
	if (texture == 0) {
		LogError2("Failed to load texture from ", afile);
		return 0;
	}
	return texture;
}

/* Initialize all setup, set screen mode, load images etc */
void InitSetup() {
	srand((int)time(NULL));
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_CreateWindowAndRenderer(WIDTH, HEIGHT, SDL_WINDOW_SHOWN, &screen, &renderer);
	if (!screen) {
		LogError("InitSetup failed to create window");
	}

	if (TTF_Init() == -1) {
		printf("TTF_Init: %s\n", TTF_GetError());
		exit(2);
	};

	textFont = loadTexture("text.png", renderer);
	font = LoadFont("/home/pi/Projects/sdlttf/font.ttf");

	SetCaption("Comparison of Bitmap vs SDL_ttf");
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);  // Black
}

/* Cleans up after game over */
void FinishOff() {
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(screen);
	//Quit SDL
	SDL_Quit();
	TTF_Quit();
	exit(0);
}

/* read a character */
char getaChar() {
	int result = -1;

	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_KEYDOWN)
		{
			result = event.key.keysym.sym;
			break;
		}
	}
	return result;
}


void renderTextureRect(SDL_Texture* tex, SDL_Rect* dst) {
	//Setup the destination rectangle to be at the position we want
	SDL_RenderCopy(renderer, tex, NULL, dst);
}

void renderTexture(SDL_Texture* tex, int x, int y) {
	//Setup the destination rectangle to be at the position we want
	dst.x = x;
	dst.y = y;
	//Query the texture to get its width and height to use
	SDL_QueryTexture(tex, NULL, NULL, &dst.w, &dst.h);
	SDL_RenderCopy(renderer, tex, NULL, &dst);
}

// print char at rect target 
void printch(char c, SDL_Rect* target) {
	SDL_Rect charblock;
	int start = (c - '!');
	if (c != ' ') {
		charblock.h = 23;
		charblock.w = 12;
		charblock.x = start * 12;
		charblock.y = 0;
		SDL_RenderCopy(renderer, textFont, &charblock, target);
	}
	(*target).x += 13;
}

// print string text at x,y pixel coords 
void print(int x, int y, char* _text) {
	SDL_Rect destr;
	int len = (int)strlen(_text);
	destr.h = 23;
	destr.w = 12;
	destr.x = x;
	destr.y = y;
	for (int i = 0; i < len; i++) {
		printch(_text[i], &destr);
	}
}

/* main game loop. Handles demo mode, high score and game play */
void GameLoop() {
	int gameRunning = 1;
	SDL_Color yellow = { 0xff,0xff,0 };
	double ttftime,sdltime;
	char timeBuffer[50];
	int w, h;
	if (TTF_SizeText(font, phrase, &w, &h)) {
		// perhaps print the current TTF_GetError(), the string can't be rendered...
	}
	else {
		printf("width=%d height=%d\n", w, h);
	}			
	SDL_Rect textRect = { 0,0,w,h };
	if (!(surface = TTF_RenderText_Solid(font, phrase, yellow))) {
		LogError2("TTF_RenderText failed", TTF_GetError());
		gameRunning = 0;
		return;
	}
	ttfTexture = SDL_CreateTextureFromSurface(renderer, surface);

	while (gameRunning)
	{		
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // Set colour to black
		SDL_RenderClear(renderer);						// Draw Background
		startTimer(&s);
		for (int i = 0; i < 100; i++) {
			int y= Random(WIDTH-100)+1;
			int x= Random(HEIGHT - 30) + 1;
			print(x, y, phrase);
		}
		stopTimer(&s);
		sdltime = diff(&s) * 1000000.0;
		startTimer(&s);
		for (int i = 0; i < 100; i++) {
			textRect.y = Random(WIDTH - 100) + 1;
			textRect.x = Random(HEIGHT - 30) + 1;
			SDL_RenderCopy(renderer, ttfTexture, 0, &textRect);
		}
		stopTimer(&s);
		ttftime = diff(&s)*1000000.0;
		SDL_RenderPresent(renderer);
		sprintf(timeBuffer, "sdl: %8.3f ttf: %8.3f", sdltime, ttftime);
		SetCaption(timeBuffer);

		while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_KEYDOWN:
				keypressed = event.key.keysym.sym;
				if (keypressed == QUITKEY)
				{
					gameRunning = 0;
					break;
				}

				break;
			case SDL_QUIT: /* if mouse click to close window */
			{
				gameRunning = 0;
				break;
			}
			case SDL_KEYUP: {
				break;
			}
			} /* switch */

		} /* while SDL_PollEvent */
	}
}

int main(int argc, char* args[])
{
	InitSetup();
	GameLoop();
	FinishOff();
	return 0;
}
