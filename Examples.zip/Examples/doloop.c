#include <stdio.h>
#include <stdbool.h>

int main()
{
	bool ended = false;
	int i = 0;
	do  {
		printf("%d\n", i);
		i += 5;
		ended = i > 20;
	} while (!ended);
	return 0;
}
