#include <stdio.h>

int main()
{
	printf("hello world\nOn a new line\n");
}

