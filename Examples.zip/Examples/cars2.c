#include <stdio.h>
#define NUMBERCARS 10
int engineCC[NUMBERCARS] = { 1600,1800,2000,2400,2500,2800,3500,4000,4500,5400 };
float topSpeed[NUMBERCARS] = { 120.0f,132.6f,142.8f,150.5f,170.8f,173.2f,175.6f, 178.4f,181.8f, 188.7f };

int main()
{
	for (int index = 0; index < 10; index = index + 1) {
		printf("Car %d Engine CC = %d Top Speed = %.2f MPH\n", index, engineCC[index], topSpeed[index]);
}
	return 0;
}
