#include <stdio.h>

int main()
{
	for (int i=0;i<=20;i+=5) {
		printf("%d\n", i);
	}
	return 0;
}
