#include <stdio.h>
#include <stdbool.h>

int main()
{
	bool ended = false;
	int i = 0;
	while (!ended) {
		printf("%d\n", i);
		i += 5;
		ended = i > 20;
	}
	return 0;
}
