#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char buffer[100];
char numberBuffer[10];
int score = 999;

int main()
{
	memcpy(buffer, "*******************", 20);
	snprintf(buffer, sizeof(buffer) - 1, "Score:%d", score++);
	printf("%s\n", buffer);
    return 0;
}
