#include <stdio.h>

int var1=5; 

int main()
{
	int var2=6;
	for (int i = 0; i < 10; i++) {
		int b = i * 2;
		int a = i + var1 + var2;
		printf("i = %d a = %d", i, a);
		int c = a * b;
		printf(" c= %d\n", c);
		int d = var3;
	}
	int var3 = var2 + c + i;
}
