#include <stdio.h>
#include <stdlib.h>

int array1[10];
int * p1 = (int *)array1;

int main()
{
	for (int i = 0; i < 10; i++) {
		array1[i] = i * i;
	}
	for (int i = 0; i < 10; i++) {
		printf("p[%d] = %d Value of *p1 = %d\n", i, array1[i], *p1++);
	}
}
