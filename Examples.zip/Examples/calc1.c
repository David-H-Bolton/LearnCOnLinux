#include <stdio.h>

int main()
{
	int a = 200;
	int b = 150;
	int c = a + b;
	int d = a - b;
	int e = a * b;
	float f = (float)a / b;
	printf("a = %d b= %d c = %d d = %d e = %d f= %f\n", a, b, c, d, e, f);
	return 0;
}
