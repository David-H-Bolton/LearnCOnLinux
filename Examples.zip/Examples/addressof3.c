#include <stdio.h>
#include <stdlib.h>

int a1;
int * p1 = &a1;

int main()
{
	a1 = 47;
	printf("Value stored in *p1 = %d\n", *p1);
	(*p1)++;
	printf("Value stored in a1 = %d\n", a1);
}

