#include <stdio.h>

int values[10];

int main() {
	for (int i = 0; i < 10; i++) {
		printf("i=%d values[i]=%d\n", i, values[i]);
	}

}
