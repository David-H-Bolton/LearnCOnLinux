#include <stdio.h>



int main()
{
	char a = 10;
	char b = 7;
	char c = a ^ b;
	printf("c = %d\n", c);

	return 0;
}
