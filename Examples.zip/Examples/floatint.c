#include <stdio.h>
#include <stddef.h>

int main()
{
	struct FloatInts {
		float f;
		short i;
		int values[10];
	};

	printf("f starts at %d\ni starts at %d\nvalues start at %d\n",
		offsetof(struct FloatInts, f),
		offsetof(struct FloatInts, i),
		offsetof(struct FloatInts, values));
	return 0;
}
