#include <stdio.h>

int value = 2;

void DecNot() {
	if (value == 0) return;
	value--;
}

void DecNot2() {
	if (!value) return;
	value--;
}

int main() {
	DecNot();
	DecNot2();
	printf("Value = %d", value);
}
