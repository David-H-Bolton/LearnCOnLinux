#include <stdio.h>
int main()
{ 
  // snippets go here
  return 0;
}